# Anonymous stopping research supplement

This is a review capsule for a research draft. It is not a submitted or accepted
NeurIPS paper. The target-year deadline and venue rules must be verified separately.

The capsule contains the qualified proofs and exact checks, deployable runtime,
the exact frozen prefix predictor, paired actual generation ledgers for 100 main
questions and 20 handpicked traps, task-disjoint archive training/calibration/
evaluation evidence, reconstructed labels, and derived historical evidence tables.
Gold ledgers are separate from public questions; controller inputs have no labels.

All four actual run ledgers are development experiments. The probability policy
stops every main and trap question at response two, so its realized behavior is a
fixed-two budget. Main accuracy is 7/100 versus 6/100 at full horizon, and trap
accuracy is 1/20 in each arm. Measured token savings do not establish a registered
noninferiority margin, conditional calibration, general adversarial robustness or
an adaptive advantage over a fixed-two policy.

Source copies with explicit local user paths or a researcher repository link have
those strings replaced. capsule_manifest.json records both original and review-
copy SHA256, sizes and redaction categories. Embedded historical source hashes
continue to describe original bytes; they are not rewritten to create a false
original identity. The deployed predictor stays byte-identical with SHA256
92fe0af86ac0f204d514a6938d0a29dace2b3cdffa24800cc4e2c85a2d51879f.

The 52-file historic trace corpus, larger matrix, OOF arrays and large LLM weights are
omitted. Their identities and coverage remain in data_manifest_v1.json. Complete
historical training environments are unknown. The two observed lock files are
inventories, not clean minimal install recipes. This capsule cannot reproduce all
historic tables without those omitted raw sources; it does support checking the
runtime, proofs, frozen artifact, task partition and actual paired evidence.

In an environment with the recorded Python/scientific dependencies, run:

```sh
python -m unittest discover -s research/tests -p 'test_*.py'
```

These tests do not generate new model responses. A live rerun needs a locally
available model snapshot and compatible GPU/software and produces a new identity;
existing model weights and original GPU timing are not reconstructed by this ZIP.
Do not run a full-corpus freeze verification on the reduced review capsule.
The original master freeze was verified before packaging; the capsule has its
own file inventory because its scope and sanitized copies differ.
